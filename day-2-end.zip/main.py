# 3 + 5
# 7 - 4
# 3 * 2
# (6 / 3)
# 2 ** 9

# # PEMDAS Left to Right
# # ()
# # #**
# # * /
# # + - 

# print(3 * 3 + 3 / 3 - 3)

#Rounding Numbers
print(round(30 / 7 , 5))

#Continuing performing evaluations w/ variables

result = 4 / 2
result /= 2
print(result)

score = 0 

#Keeping track of user's scores

score += 1
height = 1.8
isWinning = True

#f-string

print(f'your score is {score}, your height is {height}, you are winning is {isWinning}')


