name = 'Dude'
print(name)

name = 'Sweet'
print(name)

user_name = input('What is your name?')
length = len(name)
print(length)
