#Data Types

#Strings

print('Hello'[4])

print('123' + '345')

#Integer

print(123 + 345)

#Float

31452.1245

#Boolean

True
False

# num_char = len(input('What is your name?'))
# new_num_char = str(num_char)
# print('Your name has ' + new_num_char + ' characters.')

a = float(123)
print(type(a))

# print (70 + float("100.5"))
print(str(70) + str(100))

