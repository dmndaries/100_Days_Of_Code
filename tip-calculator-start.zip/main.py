#If the bill was $150.00, split between 5 people, with 12% tip. 
#Each person should pay (150.00 / 5) * 1.12 = 33.6
#Format the result to 2 decimal places = 33.60
#Tip: There are 2 ways to round a number. You might have to do some Googling to solve this.💪
#HINT 1: https://www.google.com/search?q=how+to+round+number+to+2+decimal+places+python&oq=how+to+round+number+to+2+decimal
#HINT 2: https://www.kite.com/python/answers/how-to-limit-a-float-to-two-decimal-places-in-python

print('Welcome to the tip calculator.')

#Enter the amount of the total bill
bill = float(input('What was the total of the bill? $'))

#Enter the number of people in your party that will be splitting the bill
diners = int(input('How many people will be spliting the bill? '))

#Enter the perecentage amount of tip you would like to leave
tip = int(input('How much of a tip would you like to leave? '))

bill_with_tip = tip / 100 * bill + bill
bill_split_by_diners = bill_with_tip / diners
total_cost_per_diner = '{:.2f}'.format(bill_split_by_diners)
print(f'Each person should pay: ${total_cost_per_diner}')




