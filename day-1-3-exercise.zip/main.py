#Write your code below this line 👇
#Code to Find the Length of a String

print(len(input('What is your name?')))








