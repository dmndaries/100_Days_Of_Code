import random
# Split string method
names_string = input("Give me everybody's names, separated by a comma. ")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
# Get total number of items in list:
num_items = len(names)

#Range of the number of items minus 1
random_choice = random.randint(0, num_items - 1)
#Combine random choice and names for the names to be randomly selected:
you_must_pay = names[random_choice]
print(you_must_pay + ' is going to pay for the meal for everyone.')


