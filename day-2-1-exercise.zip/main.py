# 🚨 Don't change the code below 👇
two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇

print(type(two_digit_number))

first_digit = int(two_digit_number[0])
second_digit = int(two_digit_number[1])

result = first_digit + second_digit

print(result)










